# 🛡️ Detection and Prevention of Online Banking & UPI Fraud

A rule-based fraud detection system, fraud-awareness portal, and RBI compliance checklist built to study and counter the rising wave of phishing, fake UPI collect requests, QR-code scams, and account takeovers in India's digital payments ecosystem.

> 🎓 Academic project | Department of [Your Department] | [Your College Name]

---

## 📌 Overview

India processed over **100 billion UPI transactions in 2023**, making it the world's largest real-time payment system — and a growing target for fraud. This project combines:

- 📚 Real-world cybercrime case studies
- ⚖️ Legal analysis under the **IT Act 2000** and **RBI regulations**
- 🧠 A **rule-based fraud detection engine** for transaction risk scoring
- 🌐 A **fraud awareness portal** for end users
- ✅ An interactive **RBI compliance checklist** for organizations

---

## ✨ Features

### 1. Fraud Awareness Portal
- Homepage with 6 major fraud type cards
- Detailed fraud-types page with real examples and red flags
- 10 golden safety rules for everyday users

### 2. Fraud Detection Prototype
- Web form for transaction input
- Python rule engine with 5 independent check modules
- Risk scoring bands: **Safe (0–19)** · **Low (20–39)** · **Suspicious (40–69)** · **High Risk (70–100)**

### 3. RBI Compliance Checklist
- 30 compliance items across 6 categories
- Interactive progress tracking (saved in browser)
- Printable format for audits/reports

### 4. Security Recommendations
- 7 endpoint security controls
- 7 network security controls
- 6 customer privacy risks with matching mitigations

---

## 🧮 Fraud Detection Rules

| Rule | Trigger | Score |
|------|---------|-------|
| Suspicious keywords | "OTP", "verify", "refund" in note | +15 each (max 45) |
| High amount | Above ₹10,000 | +20 |
| Very high amount | Above ₹50,000 | +35 |
| Unusual hour | 12 AM–5 AM + amount > ₹1,000 | +20 |
| Receive-type scam | Transaction type = "receive" | +40 |
| Unknown recipient | Not in trusted contacts | +15 |
| Invalid UPI ID | Missing `@` or bad format | +25 |

---

## 🛠️ Tech Stack

| Component | Technology |
|-----------|-----------|
| Frontend | HTML5, CSS3, JavaScript |
| Backend | Python 3.11, Flask |
| Detection Engine | Rule-based scoring engine |
| Storage | Browser `localStorage` (checklist progress) |

---

## 🚀 Getting Started

### Prerequisites
- Python 3.11+
- pip

### Installation
```bash
# Clone the repository
git clone https://github.com/<your-username>/upi-fraud-detection.git
cd upi-fraud-detection

# Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate   # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run the app
python app.py
```

Then open `http://localhost:5000` in your browser.

---

## 🧪 Sample Test Results

| Test Case | Input | Expected | Actual Result |
|-----------|-------|----------|----------------|
| Safe payment | ₹500 to known contact | SAFE | SAFE (score: 0) |
| Suspicious | ₹15,000 to unknown at 11 PM | SUSPICIOUS | SUSPICIOUS (score: 55) |
| Known scam | ₹50,000 receive request + OTP note | HIGH RISK | HIGH RISK (score: 100) |

---

## ⚖️ Legal Framework Referenced

| Law | Section | Applicability |
|-----|---------|----------------|
| IT Act 2000 | 66C | Identity theft via digital means |
| IT Act 2000 | 66D | Cheating by impersonation online |
| IT Act 2000 | 43A | Data protection failure |
| IPC | 420 | Cheating (non-digital overlap) |
| RBI | Master Direction 2021 | Digital payment security controls |

---

## 📸 Screenshots

> Add screenshots of the Homepage, Fraud Types page, Detector, Checklist, and Security page here.

```
/screenshots
  ├── homepage.png
  ├── fraud-types.png
  ├── detector.png
  ├── checklist.png
  └── security.png
```

---

## 📂 Project Structure

```
upi-fraud-detection/
├── app.py                  # Flask app entry point
├── requirements.txt
├── static/
│   ├── css/
│   └── js/
├── templates/
│   ├── index.html
│   ├── fraud-types.html
│   ├── detector.html
│   ├── checklist.html
│   └── security.html
├── detection/
│   └── rules_engine.py     # Rule-based scoring logic
├── screenshots/
└── README.md
```

*(Adjust to match your actual folder layout.)*

---

## 🔮 Future Enhancements

- [ ] Machine learning model trained on real fraud datasets
- [ ] Integration with bank APIs for real-time verification
- [ ] SMS/email alert system for suspicious transactions
- [ ] Mobile app version

---

## 📚 References

1. RBI Master Direction on Digital Payment Security Controls (2021)
2. NPCI UPI Operating Circulars
3. IT Act 2000 (Amended 2008) — Sections 43A, 66C, 66D
4. [cybercrime.gov.in](https://cybercrime.gov.in) — National Cyber Crime Reporting Portal

---

## 👤 Author

**[PAVAN]**

---

## 📄 License

This project is for academic purposes. Add a license (e.g., MIT) if you plan to open-source it:

```
MIT License — see LICENSE file for details
```