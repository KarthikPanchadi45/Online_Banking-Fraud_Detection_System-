# RBI Digital Payment Compliance Checklist

## 1. RBI Digital Payment Security Guidelines
- [ ] Multi-factor authentication for transactions above ₹5,000
- [ ] Transaction alerts within 30 seconds
...

## References
- RBI Master Direction on Digital Payment Security Controls (2021)
- NPCI UPI Operating Circulars
- IT Act 2000 - Sections 43A, 66C, 66D