// RBI Compliance Checklist - Interactive Logic

const STORAGE_KEY = "upi_fraud_guard_checklist";

document.addEventListener("DOMContentLoaded", function () {
    loadChecklistState();
    updateProgress();

    // Listen to all checkbox changes
    document.querySelectorAll(".checklist-item input[type='checkbox']").forEach(checkbox => {
        checkbox.addEventListener("change", function () {
            saveChecklistState();
            updateProgress();
        });
    });
});

function updateProgress() {
    const allBoxes = document.querySelectorAll(".checklist-item input[type='checkbox']");
    const total = allBoxes.length;
    const checked = document.querySelectorAll(".checklist-item input[type='checkbox']:checked").length;
    const percent = total > 0 ? Math.round((checked / total) * 100) : 0;

    // Update progress bar
    document.getElementById("progressFill").style.width = percent + "%";
    document.getElementById("progressText").textContent =
        `${checked} / ${total} completed (${percent}%)`;

    // Update summary box
    const summaryBox = document.getElementById("summaryBox");
    const summaryText = document.getElementById("summaryText");

    if (percent === 100) {
        summaryBox.style.background = "#e8f5e9";
        summaryBox.style.borderLeft = "4px solid #2e7d32";
        summaryText.innerHTML = `<strong style="color:#2e7d32;">✅ Fully Compliant (${percent}%)</strong><br>
            All ${total} requirements are met. Organization meets RBI digital payment security standards.`;
    } else if (percent >= 70) {
        summaryBox.style.background = "#fff8e1";
        summaryBox.style.borderLeft = "4px solid #f9a825";
        summaryText.innerHTML = `<strong style="color:#f57f17;">⚠️ Partially Compliant (${percent}%)</strong><br>
            ${checked} of ${total} items checked. ${total - checked} requirements still pending review.`;
    } else if (percent > 0) {
        summaryBox.style.background = "#fff3e0";
        summaryBox.style.borderLeft = "4px solid #ff6f00";
        summaryText.innerHTML = `<strong style="color:#e65100;">🔶 Low Compliance (${percent}%)</strong><br>
            Only ${checked} of ${total} items met. Significant gaps in compliance detected.`;
    } else {
        summaryBox.style.background = "#fafafa";
        summaryBox.style.borderLeft = "4px solid #ccc";
        summaryText.textContent = "Check items above to see your compliance status.";
    }

    // Color progress bar
    const fill = document.getElementById("progressFill");
    if (percent >= 70) fill.style.background = "#2e7d32";
    else if (percent >= 40) fill.style.background = "#ff6f00";
    else fill.style.background = "#c62828";
}

function saveChecklistState() {
    const state = {};
    document.querySelectorAll(".checklist-item input[type='checkbox']").forEach(box => {
        state[box.dataset.id] = box.checked;
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function loadChecklistState() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return;

    const state = JSON.parse(saved);
    document.querySelectorAll(".checklist-item input[type='checkbox']").forEach(box => {
        if (state[box.dataset.id]) {
            box.checked = true;
        }
    });
}

function resetChecklist() {
    if (confirm("Reset all checklist items?")) {
        document.querySelectorAll(".checklist-item input[type='checkbox']").forEach(box => {
            box.checked = false;
        });
        localStorage.removeItem(STORAGE_KEY);
        updateProgress();
    }
}