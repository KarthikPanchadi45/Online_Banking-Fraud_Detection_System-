// Simple welcome log - proves JS is connected
console.log("UPI Fraud Guard portal loaded successfully!");

// Highlight active nav link based on current page
document.addEventListener("DOMContentLoaded", function () {
    const currentPage = window.location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll(".nav-links a").forEach(link => {
        if (link.getAttribute("href").includes(currentPage)) {
            link.classList.add("active");
        }
    });
});