const API_URL = "http://localhost:5000/api/check-fraud";

// Sample test scenarios
const testScenarios = {
    safe: {
        upi_id: "rahul@oksbi",
        amount: 500,
        note: "Lunch payment",
        tx_type: "pay",
        hour: 13,
        is_known_recipient: true
    },
    suspicious: {
        upi_id: "unknownseller@paytm",
        amount: 15000,
        note: "OLX phone payment",
        tx_type: "pay",
        hour: 23,
        is_known_recipient: false
    },
    danger: {
        upi_id: "refunddesk@ybl",
        amount: 50000,
        note: "Verify OTP to receive refund urgently",
        tx_type: "receive",
        hour: 2,
        is_known_recipient: false
    }
};

// Load a test scenario into the form
function loadTest(type) {
    const scenario = testScenarios[type];
    document.getElementById("upi_id").value = scenario.upi_id;
    document.getElementById("amount").value = scenario.amount;
    document.getElementById("note").value = scenario.note;
    document.getElementById("tx_type").value = scenario.tx_type;
    document.getElementById("hour").value = scenario.hour;
    document.getElementById("is_known_recipient").checked = scenario.is_known_recipient;
}

// Handle form submission
document.getElementById("fraudForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    const resultPanel = document.getElementById("resultPanel");
    resultPanel.innerHTML = `<div class="card" style="cursor:default; text-align:center; padding:40px;">
        <p>⏳ Analyzing transaction...</p>
    </div>`;

    const payload = {
        upi_id: document.getElementById("upi_id").value,
        amount: parseFloat(document.getElementById("amount").value),
        note: document.getElementById("note").value,
        tx_type: document.getElementById("tx_type").value,
        hour: parseInt(document.getElementById("hour").value),
        is_known_recipient: document.getElementById("is_known_recipient").checked
    };

    try {
        const response = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (data.success) {
            displayResult(data.result);
        } else {
            resultPanel.innerHTML = `<div class="card result-error" style="cursor:default;">
                <h3>❌ Error</h3><p>${data.error}</p>
            </div>`;
        }
    } catch (error) {
        resultPanel.innerHTML = `<div class="card result-error" style="cursor:default;">
            <h3>❌ Connection Error</h3>
            <p>Could not connect to the fraud detection server.</p>
            <p><strong>Make sure the Python server is running:</strong></p>
            <code style="background:#f0f0f0; padding:8px; display:block; margin-top:10px;">
                cd backend && python app.py
            </code>
        </div>`;
    }
});

// Display fraud check result
function displayResult(result) {
    const colorMap = {
        green:  { bg: "#e8f5e9", border: "#2e7d32", text: "#2e7d32" },
        yellow: { bg: "#fffde7", border: "#f9a825", text: "#f57f17" },
        orange: { bg: "#fff3e0", border: "#ff6f00", text: "#e65100" },
        red:    { bg: "#ffebee", border: "#c62828", text: "#c62828" }
    };

    const colors = colorMap[result.risk_color] || colorMap.yellow;

    let reasonsHTML = "";
    if (result.reasons.length > 0) {
        reasonsHTML = `<ul class="reasons-list">
            ${result.reasons.map(r => `<li>${r}</li>`).join("")}
        </ul>`;
    } else {
        reasonsHTML = "<p>No fraud indicators detected.</p>";
    }

    document.getElementById("resultPanel").innerHTML = `
        <div class="card result-card" style="cursor:default; background:${colors.bg}; border: 2px solid ${colors.border};">
            <div class="result-score" style="color:${colors.text}">
                <span class="score-number">${result.risk_score}</span>
                <span class="score-label">/ 100</span>
            </div>
            <div class="result-level" style="color:${colors.text}">
                ${result.risk_level}
            </div>
            <p class="result-action">${result.action}</p>
            <hr style="margin: 15px 0; border: none; border-top: 1px solid ${colors.border}40;">
            <h4 style="color:${colors.text}">Detection Details:</h4>
            ${reasonsHTML}
            <p style="font-size:0.8rem; color:#888; margin-top:15px;">
                ${result.checks_run} checks performed | ${new Date(result.timestamp).toLocaleTimeString()}
            </p>
        </div>
    `;
}