"""
UPI Fraud Detection Rules Engine
Checks transaction details against known fraud patterns.
"""

import re
from datetime import datetime

# Suspicious keywords often used in scams
SUSPICIOUS_KEYWORDS = [
    "otp", "verify", "refund", "kyc", "update", "blocked",
    "lottery", "prize", "won", "cashback", "urgent", "immediately",
    "safe account", "rbi", "police", "investment", "double",
    "earn", "task", "registration", "confirm", "activate",
    "suspend", "expire", "click here", "free money"
]

# Known suspicious UPI ID patterns
SUSPICIOUS_UPI_PATTERNS = [
    r"paytmqr",           # Often used in QR scams
    r"qr\d+",             # Generic QR IDs from unknown sources
    r".*fake.*",
    r".*scam.*",
    r".*test.*pay.*",
]

# High-risk amount thresholds (in INR)
HIGH_AMOUNT_THRESHOLD = 10000
VERY_HIGH_AMOUNT_THRESHOLD = 50000


def check_suspicious_keywords(transaction_note: str) -> dict:
    """Check if transaction note contains scam-related keywords."""
    if not transaction_note:
        return {"flagged": False, "score": 0, "reasons": []}

    note_lower = transaction_note.lower()
    found_keywords = [kw for kw in SUSPICIOUS_KEYWORDS if kw in note_lower]

    if found_keywords:
        score = min(len(found_keywords) * 15, 45)
        return {
            "flagged": True,
            "score": score,
            "reasons": [f"Suspicious keyword detected: '{kw}'" for kw in found_keywords]
        }
    return {"flagged": False, "score": 0, "reasons": []}


def check_upi_id(upi_id: str) -> dict:
    """Validate UPI ID format and check for suspicious patterns."""
    reasons = []
    score = 0

    if not upi_id or not upi_id.strip():
        return {"flagged": True, "score": 20, "reasons": ["UPI ID is empty or missing"]}

    upi_id = upi_id.strip().lower()

    # Basic UPI format: name@bank
    if "@" not in upi_id:
        score += 25
        reasons.append("Invalid UPI ID format (missing @ symbol)")

    parts = upi_id.split("@")
    if len(parts) != 2:
        score += 25
        reasons.append("Invalid UPI ID structure")

    # Check suspicious patterns
    for pattern in SUSPICIOUS_UPI_PATTERNS:
        if re.search(pattern, upi_id):
            score += 20
            reasons.append(f"Suspicious UPI ID pattern detected")

    # Very long or very short UPI IDs
    if len(upi_id) > 50:
        score += 10
        reasons.append("Unusually long UPI ID")

    return {
        "flagged": score > 0,
        "score": min(score, 40),
        "reasons": reasons
    }


def check_amount(amount: float, hour: int) -> dict:
    """Check if amount is unusually high, especially at odd hours."""
    reasons = []
    score = 0

    if amount <= 0:
        return {"flagged": True, "score": 30, "reasons": ["Invalid amount (zero or negative)"]}

    if amount >= VERY_HIGH_AMOUNT_THRESHOLD:
        score += 35
        reasons.append(f"Very high amount: ₹{amount:,.0f} (above ₹{VERY_HIGH_AMOUNT_THRESHOLD:,})")
    elif amount >= HIGH_AMOUNT_THRESHOLD:
        score += 20
        reasons.append(f"High amount: ₹{amount:,.0f} (above ₹{HIGH_AMOUNT_THRESHOLD:,})")

    # Odd hour transactions (midnight to 5 AM)
    if 0 <= hour <= 5 and amount >= 1000:
        score += 20
        reasons.append(f"Transaction at unusual hour ({hour}:00 AM) with significant amount")

    return {
        "flagged": score > 0,
        "score": min(score, 45),
        "reasons": reasons
    }


def check_transaction_type(tx_type: str) -> dict:
    """Check if user might be confused about pay vs receive."""
    reasons = []
    score = 0

    if tx_type and tx_type.lower() in ["receive", "accept", "collect"]:
        # If they're entering PIN for "receive" - classic scam
        score += 40
        reasons.append(
            "CRITICAL: You should NEVER enter UPI PIN to RECEIVE money. "
            "This is a classic fake UPI request scam!"
        )

    return {
        "flagged": score > 0,
        "score": score,
        "reasons": reasons
    }


def check_recipient_known(is_known: bool) -> dict:
    """Check if recipient is a known/trusted contact."""
    if not is_known:
        return {
            "flagged": True,
            "score": 15,
            "reasons": ["Recipient is not in your known/trusted contacts"]
        }
    return {"flagged": False, "score": 0, "reasons": []}


def calculate_risk_score(transaction: dict) -> dict:
    """
    Main function: run all rules and return final risk assessment.

    Expected transaction dict keys:
    - upi_id: str
    - amount: float
    - note: str
    - tx_type: str ("pay" or "receive")
    - is_known_recipient: bool
    - hour: int (0-23, optional - defaults to current hour)
    """
    all_reasons = []
    total_score = 0

    hour = transaction.get("hour", datetime.now().hour)

    # Run all rule checks
    checks = [
        check_upi_id(transaction.get("upi_id", "")),
        check_amount(float(transaction.get("amount", 0)), hour),
        check_suspicious_keywords(transaction.get("note", "")),
        check_transaction_type(transaction.get("tx_type", "pay")),
        check_recipient_known(transaction.get("is_known_recipient", False)),
    ]

    for check in checks:
        total_score += check["score"]
        all_reasons.extend(check["reasons"])

    # Cap score at 100
    total_score = min(total_score, 100)

    # Determine risk level
    if total_score >= 70:
        risk_level = "HIGH RISK"
        risk_color = "red"
        action = "DO NOT PROCEED — This transaction shows multiple fraud indicators."
    elif total_score >= 40:
        risk_level = "SUSPICIOUS"
        risk_color = "orange"
        action = "Proceed with caution — Verify recipient details before paying."
    elif total_score >= 20:
        risk_level = "LOW RISK"
        risk_color = "yellow"
        action = "Minor concerns detected — Double-check before confirming."
    else:
        risk_level = "SAFE"
        risk_color = "green"
        action = "No major fraud indicators detected. Still verify recipient before paying."

    return {
        "risk_score": total_score,
        "risk_level": risk_level,
        "risk_color": risk_color,
        "reasons": all_reasons,
        "action": action,
        "checks_run": len(checks),
        "timestamp": datetime.now().isoformat()
    }