"""
UPI Fraud Guard - Flask API Server
Connects the fraud detection engine to the web frontend.
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from rules.fraud_rules import calculate_risk_score

app = Flask(__name__)
CORS(app)  # Allow frontend to call this API


@app.route("/")
def home():
    return jsonify({
        "status": "running",
        "message": "UPI Fraud Guard API is active",
        "endpoint": "POST /api/check-fraud"
    })


@app.route("/api/check-fraud", methods=["POST"])
def check_fraud():
    """Receive transaction data and return fraud risk assessment."""
    try:
        data = request.get_json()

        if not data:
            return jsonify({"error": "No data provided"}), 400

        # Validate required fields
        required = ["upi_id", "amount"]
        missing = [field for field in required if not data.get(field)]
        if missing:
            return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 400

        # Build transaction object
        transaction = {
            "upi_id": str(data.get("upi_id", "")),
            "amount": float(data.get("amount", 0)),
            "note": str(data.get("note", "")),
            "tx_type": str(data.get("tx_type", "pay")),
            "is_known_recipient": bool(data.get("is_known_recipient", False)),
            "hour": int(data.get("hour", 12))
        }

        # Run fraud detection
        result = calculate_risk_score(transaction)
        return jsonify({"success": True, "result": result})

    except ValueError as e:
        return jsonify({"error": f"Invalid input: {str(e)}"}), 400
    except Exception as e:
        return jsonify({"error": f"Server error: {str(e)}"}), 500


if __name__ == "__main__":
    print("Starting UPI Fraud Guard API on http://localhost:5000")
    app.run(debug=True, port=5000)