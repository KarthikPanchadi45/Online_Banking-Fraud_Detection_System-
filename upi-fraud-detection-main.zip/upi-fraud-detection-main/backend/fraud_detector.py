"""
UPI Fraud Guard - Main Detector
Run this file directly to test the fraud detection engine.
"""

import json
import sys
import os

# Allow importing from rules folder
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rules.fraud_rules import calculate_risk_score


def run_demo_tests():
    """Run sample test cases to verify the engine works."""
    test_cases = [
        {
            "name": "✅ Safe transaction",
            "data": {
                "upi_id": "friend@oksbi",
                "amount": 500,
                "note": "Dinner payment",
                "tx_type": "pay",
                "is_known_recipient": True,
                "hour": 14
            }
        },
        {
            "name": "⚠️ Suspicious - high amount + unknown recipient",
            "data": {
                "upi_id": "unknownseller@paytm",
                "amount": 15000,
                "note": "OLX item payment",
                "tx_type": "pay",
                "is_known_recipient": False,
                "hour": 22
            }
        },
        {
            "name": "🚨 HIGH RISK - fake receive + OTP keyword",
            "data": {
                "upi_id": "scammer@ybl",
                "amount": 50000,
                "note": "Verify OTP to receive refund amount urgently",
                "tx_type": "receive",
                "is_known_recipient": False,
                "hour": 2
            }
        }
    ]

    print("=" * 60)
    print("  UPI FRAUD GUARD - Detection Engine Test")
    print("=" * 60)

    for test in test_cases:
        result = calculate_risk_score(test["data"])
        print(f"\n{test['name']}")
        print(f"  Input: {test['data']['upi_id']} | ₹{test['data']['amount']} | '{test['data']['note']}'")
        print(f"  Result: {result['risk_level']} (Score: {result['risk_score']}/100)")
        print(f"  Action: {result['action']}")
        if result["reasons"]:
            print("  Reasons:")
            for reason in result["reasons"]:
                print(f"    - {reason}")

    print("\n" + "=" * 60)
    print("All tests completed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    run_demo_tests()